import numpy as np
import torch
from torch_geometric.nn import HypergraphConv,GATConv
import torch.nn as nn

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class Hyperrna(nn.Module):
    def __init__(self, in_circfeat_size, outfeature_size, heads):
        super(Hyperrna, self).__init__()
        self.in_circfeat_size = in_circfeat_size
        self.outfeature_size = outfeature_size
        self.heads = heads
        self.conv1 = HypergraphConv(512, 256, use_attention=True, heads=2, concat=True, negative_slope=0.2,
                                    dropout=0.5, bias=True)


        # 定义参数初始化函数
        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)

        # 初始化
        self.conv1.apply(init_weights)



    def process_hypergraph(self, cnn_output1,hyperedge_index,hyperedge_weight,hyperedge_attr):

        output = self.conv1(cnn_output1,hyperedge_index,hyperedge_weight,hyperedge_attr)



        return output

    def forward(self, cnn_output1,hyperedge_index,hyperedge_weight,hyperedge_attr):

        output = self.process_hypergraph(cnn_output1,hyperedge_index,hyperedge_weight,hyperedge_attr)

        return output

