import argparse
import math
import random
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from GAT import GAT
from utils import build_heterograph, sort_matrix
from sklearn.metrics import roc_curve, precision_recall_curve

import matplotlib.pyplot as plt

# 参数设置
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=2022, help='Random seed.')
parser.add_argument('--epochs', type=int, default=80,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.0001,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-7,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=64,
                    help='Dimension of representations')

if __name__ == '__main__':
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    # 随机种子
    torch.manual_seed(args.seed)

    # 读取邻接矩阵,3077*313
    CD = pd.read_excel(r'rna+dis+matrix.xlsx', index_col=0)
    CD = CD.values
    print(1)
    CM = pd.read_excel(r'circ-mi-661-1695.xlsx')
    CM = CM.values
    print(2)
    MD = pd.read_excel(r'dis-mi-100-1695.xlsx')
    MD = MD.values
    print(3)

    circSimi = pd.read_excel(r'rna_GaussianSimilarity.xlsx', index_col=0)
    circSimi = circSimi.values
    print(4)
    disSimi = pd.read_excel(r'disease_GaussianSimilarity.xlsx', header=None)
    disSimi = disSimi.values
    print(5)
    miSimi = pd.read_excel(r'mi_GaussianSimilarity.xlsx')
    miSimi = miSimi.values


    dis = pd.read_excel(r'dis.xlsx', index_col=0)
    dis = dis.values
    print(5)
    circ = pd.read_excel(r'circ.xlsx', index_col=0)
    circ = circ.values
    print(5)
    mi = pd.read_excel(r'mi_GaussianSimilarity.xlsx')
    mi= mi.values


    similarity_Graph_c = pd.read_excel(r'similarity_Graph_c.xlsx')
    similarity_Graph_c = similarity_Graph_c.values
    print(7)
    similarity_Graph_d = pd.read_excel(r'similarity_Graph_d.xlsx')
    similarity_Graph_d = similarity_Graph_d.values
    print(7)
    similarity_Graph_m = pd.read_excel(r'similarity_Graph_m.xlsx')
    similarity_Graph_m = similarity_Graph_m.values
    print(7)

    # 将两矩阵numpy转成tensor
    # 3077*3077
    circSimi_mat = torch.from_numpy(circSimi).to(torch.float32)
    # 313*313
    disSimi_mat = torch.from_numpy(disSimi).to(torch.float32)
    miSimi_mat = torch.from_numpy(miSimi).to(torch.float32)
    similarity_Graph_c_mat = torch.from_numpy(similarity_Graph_c).to(torch.float32)
    similarity_Graph_d_mat = torch.from_numpy(similarity_Graph_d).to(torch.float32)
    similarity_Graph_m_mat = torch.from_numpy(similarity_Graph_m).to(torch.float32)


    circ = torch.from_numpy(circ).to(torch.float32)
    # 313*313
    dis = torch.from_numpy(dis).to(torch.float32)
    mi = torch.from_numpy(mi).to(torch.float32)
    # 3077*313
    circrna_disease_matrix = np.copy(CD)
    circrna_mirna_matrix = np.copy(CM)
    # 313*847
    mirna_disease_matrix = np.copy(MD)
    # 3077
    rna_numbers = circrna_disease_matrix.shape[0]
    # 313
    dis_number = circrna_disease_matrix.shape[1]
    # 847
    # mi_number = MD.shape[1]

    # 寻找正样本的索引
    positive_index_tuple = np.where(circrna_disease_matrix == 1)
    # 3808
    positive_index_list = list(zip(positive_index_tuple[0], positive_index_tuple[1]))

    # 随机打乱
    random.shuffle(positive_index_list)

    # 将正样本分为5个数量相等的部分 762
    positive_split = math.ceil(len(positive_index_list) / 5)
    # positive_split = 1

    all_tpr = []
    all_fpr = []
    all_recall = []
    all_precision = []
    all_accuracy = []
    all_F1 = []

    count = 0

    print('starting fivefold cross validation..................')
    for i in range(0, len(positive_index_list), positive_split):
        count = count + 1
        print("This is {} fold cross validation".format(count))

        # 抽取五折中的一份  762
        positive_train_index_to_zero = positive_index_list[i: i + positive_split]
        # 3077*313
        new_circrna_disease_matrix = circrna_disease_matrix.copy()

        # 五分之一的正样本置为0
        for index in positive_train_index_to_zero:
            new_circrna_disease_matrix[index[0], index[1]] = 0

        # 将矩阵 numpy转为tensor
        # 3077*313
        new_circrna_disease_matrix_tensor = torch.from_numpy(new_circrna_disease_matrix).to(device)
        new_circrna_mirna_matrix_tensor = torch.from_numpy(circrna_mirna_matrix).to(device)
        # 313*847
        new_mirna_disease_matrix_tensor = torch.from_numpy(mirna_disease_matrix).to(device)
        roc_circrna_disease_matrix = new_circrna_disease_matrix + circrna_disease_matrix

        # 异构邻接矩阵  节点：761 边：194123
        gcd, gcm, gmd = build_heterograph(new_circrna_disease_matrix, new_circrna_mirna_matrix_tensor,
                                          new_mirna_disease_matrix_tensor, circSimi, disSimi, miSimi)
        gcd = gcd.to(device)
        gcm = gcm.to(device)
        gmd = gmd.to(device)

        circSimi_mat = circSimi_mat.to(device)
        disSimi_mat = disSimi_mat.to(device)
        miSimi_mat = miSimi_mat.to(device)
        similarity_Graph_c = similarity_Graph_c_mat.to(device)
        similarity_Graph_d =  similarity_Graph_d_mat.to(device)
        similarity_Graph_m =   similarity_Graph_m_mat.to(device)

        circ = circ.to(device)
        dis = dis.to(device)
        mi = mi.to(device)

        model = GAT(661, 100,847, 128, 8, 0.1, 0.3, 1536, 1).to(device)  #
        # 声明参数优化器
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        # steps = []
        # loss_value = []

        # 模型训练
        model.train()
        for epoch in range(args.epochs):
            train_predict_result, train_lable = model(gcd,gcm,gmd, circSimi_mat, disSimi_mat, miSimi_mat, similarity_Graph_c_mat,similarity_Graph_d_mat,similarity_Graph_m_mat,
                                                     circ, dis,mi, new_circrna_disease_matrix_tensor,
                                                      train_model=True)
            loss = F.binary_cross_entropy(train_predict_result, train_lable)
            # steps.append(epoch)
            # loss_value.append(loss.item())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            print('Epoch %d | train Loss: %.4f' % (epoch + 1, loss.item()))

        # 模型评估
        model.eval()
        with torch.no_grad():
            test_predict_result, test_lable = model(gcd,gcm,gmd, circSimi_mat, disSimi_mat,miSimi_mat , similarity_Graph_c_mat,similarity_Graph_d_mat,similarity_Graph_m_mat,
                                                     circ, dis, mi,new_circrna_disease_matrix_tensor,
                                                    train_model=False)
        #     test_lable.cpu().numpy()
        # fpr, tpr, threshold = roc_curve(test_lable, test_predict_result)
        # pre,re,thresholds=precision_recall_curve(test_lable, test_predict_result)
        #
        # print('AUC value ：', np.trapz(tpr, fpr))
        # print('AUPR value ：', np.trapz(re, pre))

        # 将test_predict_result传入到prediction_matrix中
        prediction_matrix = np.zeros(circrna_disease_matrix.shape)  # 661*100
        for num in range(test_predict_result.size()[0]):  # 66100
            row_num = num // dis_number  #
            col_num = num % dis_number
            prediction_matrix[row_num, col_num] = test_predict_result[num, 0]

        # print(top10)
        # df = pd.DataFrame(top10, columns=['col1', 'col2'])
        # df.to_excel('top50.xlsx', index=False)

        zero_matrix = np.zeros(prediction_matrix.shape).astype('int64')  # 661*100
        prediction_matrix_temp = prediction_matrix.copy()  # 661*100
        prediction_matrix_temp = prediction_matrix_temp + zero_matrix
        min_value = np.min(prediction_matrix_temp)  # 0

        index_where_2 = np.where(roc_circrna_disease_matrix == 2)
        # 使参数训练的正样本得分在排序的时候下沉(从大到小排序)
        prediction_matrix_temp[index_where_2] = min_value - 20

        # 得分排序(得分矩阵排序以及对应的关联矩阵排序)
        sorted_rna_dis_matrix, sorted_prediction_matrix = sort_matrix(prediction_matrix_temp,
                                                                      roc_circrna_disease_matrix)

        tpr_list = []
        fpr_list = []
        recall_list = []
        precision_list = []
        accuracy_list = []
        F1_list = []
        for cutoff in range(sorted_rna_dis_matrix.shape[0]):
            P_matrix = sorted_rna_dis_matrix[0:cutoff + 1, :]
            N_matrix = sorted_rna_dis_matrix[cutoff + 1:sorted_rna_dis_matrix.shape[0] + 1, :]
            TP = np.sum(P_matrix == 1)
            FP = np.sum(P_matrix == 0)
            TN = np.sum(N_matrix == 0)
            FN = np.sum(N_matrix == 1)
            tpr = TP / (TP + FN)
            fpr = FP / (FP + TN)
            accuracy = (TN + TP) / (TN + TP + FN + FP)
            F1 = (2 * TP) / (2 * TP + FP + FN)
            recall = TP / (TP + FN)
            precision = TP / (TP + FP)
            tpr_list.append(tpr)
            fpr_list.append(fpr)
            recall_list.append(recall)
            precision_list.append(precision)
            F1_list.append(F1)
            accuracy_list.append(accuracy)

        top_list = [10, 20, 50, 100, 200]

        for num in top_list:
            P_matrix = sorted_rna_dis_matrix[0:num, :]
            N_matrix = sorted_rna_dis_matrix[num:sorted_rna_dis_matrix.shape[0] + 1, :]
            top_count = np.sum(P_matrix == 1)
            print("top" + str(num) + ": " + str(top_count))

        all_tpr.append(tpr_list)
        all_fpr.append(fpr_list)
        all_recall.append(recall_list)
        all_precision.append(precision_list)
        all_accuracy.append(accuracy_list)
        all_F1.append(F1_list)

    tpr_arr = np.array(all_tpr)
    fpr_arr = np.array(all_fpr)
    recall_arr = np.array(all_recall)
    precision_arr = np.array(all_precision)
    accuracy_arr = np.array(all_accuracy)
    F1_arr = np.array(all_F1)

    # 绘制每条曲线
    # draw_alone_validation_roc_line(tpr_arr, fpr_arr)

    # 保存tpr,fpr数据
    np.savetxt('tpr_arr_mean_att.csv', tpr_arr, delimiter=',')
    np.savetxt("fpr_arr_mean_att.csv", fpr_arr, delimiter=',')
    np.savetxt('recall_arr_mean_att.csv', recall_arr, delimiter=',')
    np.savetxt("precision_arr_mean_att.csv", precision_arr, delimiter=',')

    mean_cross_tpr = np.mean(tpr_arr, axis=0)  # axis=0
    mean_cross_fpr = np.mean(fpr_arr, axis=0)
    mean_cross_recall = np.mean(recall_arr, axis=0)
    mean_cross_precision = np.mean(precision_arr, axis=0)
    mean_cross_accuracy = np.mean(accuracy_arr, axis=0)

    np.savetxt('mean_cross_tpr_mean_att.csv', mean_cross_tpr, delimiter=',')
    np.savetxt('mean_cross_fpr_mean_att.csv', mean_cross_fpr, delimiter=',')
    np.savetxt('mean_cross_recall_mean_att.csv', mean_cross_recall, delimiter=',')
    np.savetxt('mean_cross_precision_mean_att.csv', mean_cross_precision, delimiter=',')

    # 计算此次五折的平均评价指标数值
    mean_accuracy = np.mean(np.mean(accuracy_arr, axis=1), axis=0)
    mean_accuracy1 = np.mean(accuracy_arr)
    mean_recall = np.mean(np.mean(recall_arr, axis=1), axis=0)
    mean_precision = np.mean(np.mean(precision_arr, axis=1), axis=0)
    mean_F1 = np.mean(np.mean(F1_arr, axis=1), axis=0)
    print("accuracy:%.4f,recall:%.4f,precision:%.4f,F1:%.4f" % (mean_accuracy, mean_recall, mean_precision, mean_F1))

    roc_auc = np.trapz(mean_cross_tpr, mean_cross_fpr)
    AUPR = np.trapz(mean_cross_precision, mean_cross_recall)
    print("AUC:%.4f,AUPR:%.4f" % (roc_auc, AUPR))
    plt.plot(mean_cross_fpr, mean_cross_tpr, label='mean ROC=%0.4f' % roc_auc)
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.legend(loc=0)
    plt.show()
